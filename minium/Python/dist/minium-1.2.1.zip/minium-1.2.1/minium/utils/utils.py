#!/usr/local/bin/python3
# -*- coding: utf-8 -*-
"""
Author:         yopofeng
Filename:       utils.py
Create time:    2021/9/24 21:21
Description:

"""
import time
from functools import wraps
import typing
import platform


def timeout(duration):
    """
    重试超时装饰器，在超时之前会每隔一秒重试一次
    注意：被修饰的函数必须要有非空返回，这是重试终止的条件！！！
    :param duration: seconds
    :return:
    """

    def spin_until_true(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            timeout = time.time() + duration
            r = func(*args, **kwargs)
            time.sleep(1)
            while not (r or timeout < time.time()):
                r = func(*args, **kwargs)
                time.sleep(1)
            return r

        return wrapper

    return spin_until_true


_platform = platform.platform()
isWindows = "Windows" in _platform
isMacOS = "Darwin" in _platform or "macOS" in _platform
