#!/usr/bin/env python3
import ddt
__all__=["ddt_class","ddt_case","ddt_unpack"]
def ddt_class(cls):
 return ddt.ddt(cls)
def ddt_case(*values):
 return ddt.data(*values)
def ddt_unpack(func):
 return ddt.unpack(func)
# Created by pyminifier (https://github.com/liftoff/pyminifier)
