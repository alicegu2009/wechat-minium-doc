#!/usr/local/bin/python3
# -*- coding: utf-8 -*-
from.wx_minium import WXMinium
from.qq_minium import QQMinium
APP_WX="wx"
APP_QQ="qq"
APP={"wx":WXMinium,"qq":QQMinium}
def get_minium_driver(conf):
 if conf.get("app",None)not in[APP_WX,APP_QQ]:
  raise RuntimeError("the 'app' in your config file is not in predefine, not support yet")
 return APP[conf.get("app","wx")](conf)
# Created by pyminifier (https://github.com/liftoff/pyminifier)
