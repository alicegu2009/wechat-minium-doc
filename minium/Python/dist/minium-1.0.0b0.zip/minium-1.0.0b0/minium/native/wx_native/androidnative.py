#!/usr/bin/env python3
import os.path
import at
import time
from.basenative import BaseNative,NativeError
import json
import logging
import threading
WECHAT_PACKAGE="com.tencent.mm"
WECHAT_ACTIVITY="ui.LauncherUI"
logger=logging.getLogger()
class UiDefine:
 def __init__(self,_at:at.At):
  self.at=_at
  self.btn_authorize_ok=self.at.e.cls_name("android.widget.Button").text("允许")
  self.btn_authorize_cancel=self.at.e.cls_name("android.widget.Button").text("取消")
  self.action_menu=self.at.e.cls_name("android.widget.ImageButton").desc("更多")
  self.action_home=self.at.e.cls_name("android.widget.ImageButton").desc("关闭")
  self.title=(self.action_home.parent().cls_name("android.widget.LinearLayout").instance(1).child().cls_name("android.widget.TextView"))
  self.comp_picker_input=self.at.e.cls_name("android.widget.EditText").rid("android:id/numberpicker_input")
class WXAndroidNative(BaseNative):
 def __init__(self,json_conf):
  super(WXAndroidNative,self).__init__(json_conf)
  if json_conf is None:
   json_conf={}
  self.serial=json_conf.get("serial")
  uiautomator_version=int(json_conf.get("uiautomator_version","2"))
  at.uiautomator_version=uiautomator_version
  self.at=at.At(self.serial)
  self.at.java_driver.set_capture_op(False)
  self.ui=UiDefine(self.at)
  self.lang=json_conf.get("lang")
  self.perf_thread=None
  self.fps_data_dict={} 
  self.jank_count_dict={} 
  self.fps_thread=None
 def connect_weapp(self,path):
  self.at.apkapi.launch()
  gallery_name="atstub"
  self.at.apkapi.add_gallery(path)
  self.stop_wechat()
  self.start_wechat()
  if self.lang=="en":
   self.e.text("Discover").click()
   self.e.text("Scan").click()
   self.e.cls_name("android.widget.LinearLayout").instance(1).click()
   self.e.text("All Images").click()
   self.e.text(gallery_name).click()
   self.e.desc_contains("Image 1").click()
   self.e.text_contains("Scanning").wait_disappear()
  else:
   self.e.text("发现").click()
   self.e.text("扫一扫").click()
   self.e.cls_name("android.widget.LinearLayout").instance(1).click()
   self.e.text("所有图片").click()
   self.e.text(gallery_name).click()
   self.e.desc_contains("图片 1").click()
   self.e.text_contains("扫描中").wait_disappear()
 def screen_shot(self,filename,quality=30):
  return self.at.device.screen_shot(filename,quality=quality)
 def pick_media_file(self,cap_type="camera",media_type="photo",original=False,duration=5.0,index_list=None,):
  pass
 def input_text(self,text):
  self.at.e.edit_text().enter(text,is_click=False)
 def input_clear(self):
  self.at.e.edit_text().enter("",is_click=False)
 def textarea_text(self,text,index=0):
  self.at.e.edit_text().instance(index).enter(text,is_click=False)
 def textarea_clear(self,index=0):
  self.at.e.edit_text().instance(index).enter("",is_click=False)
 def map_select_location(self,name):
  print("map_select_location")
  self.at.e.text("搜索地点").click()
  self.at.e.edit_text().enter_chinese(name)
  self.at.adb.press_search()
  self.at.adb.press_back()
  while self.at.e.rid("com.tencent.mm:id/poi_item_location").exists():
   try:
    self.at.e.rid("com.tencent.mm:id/poi_item_location").click()
    if self.at.e.rid("com.tencent.mm:id/btn_send_txt").exists:
     break
   except Exception as e:
    logger.warning(str(e))
  self.at.e.rid("com.tencent.mm:id/btn_send_txt").click()
 def map_back_to_mp(self):
  self.at.e.rid("com.tencent.mm:id/btn_back_txt").click()
 def deactivate(self,duration):
  self.at.adb.press_home()
  time.sleep(duration)
  self.at.adb.start_app("com.tencent.mm","ui.LauncherUI","-n")
  time.sleep(2)
  screen_width=int(self.at.device.width())
  screen_height=int(self.at.device.height())
  self.at.device.swipe(int(screen_width/2),int(screen_height*1/4),int(screen_width/2),int(screen_height*4/5),10,)
  time.sleep(2)
  self.textbounds=self.at.e.rid("com.tencent.mm:id/test_mask").get_bounds()
  print(self.textbounds)
  xx=self.textbounds[0]
  yy=self.textbounds[1]
  self.at.adb.click_point(xx,yy)
 def _allow_authorize(self,answer):
  if answer:
   self.ui.btn_authorize_ok.click()
  else:
   self.ui.btn_authorize_cancel.click()
 def allow_login(self,answer=True):
  self._allow_authorize(answer)
 def allow_get_user_info(self,answer=True):
  self._allow_authorize(answer)
 def allow_get_location(self,answer=True):
  pass
 def handle_modal(self,btn_text="确定",title=None):
  if title:
   if not self.e.text(title).exists():
    logger.info("没有出现预期弹窗：title[%s]",title)
    return False
   self.e.cls_name("android.widget.Button").focusable(True).text(btn_text).click()
  else:
   if not self.e.text(btn_text).exists():
    logger.error("没有出现预期button：%s",btn_text)
    return False
   self.e.cls_name("android.widget.Button").focusable(True).text(btn_text).click()
 def handle_action_sheet(self,item):
  self.e.cls_name("android.widget.TextView").text(item).click()
 def forward_miniprogram(self,name,text=None,create_new_chat=True):
  self.ui.action_menu.click()
  self.e.text("发送给朋友").click()
  return self.forward_miniprogram_inside(name,text,create_new_chat)
 def forward_miniprogram_inside(self,name,text=None,create_new_chat=True):
  if create_new_chat:
   self.e.text("创建新聊天").click()
   self.e.text_contains(name).click(True)
   self.e.text("确定(1)").enabled(True).click()
  else:
   self.e.text_contains(name).click(True)
  if text:
   self.e.edit_text().enter(text)
  self.e.cls_name("android.widget.Button").text("发送").click()
  self.e.text("已转发").wait_disappear()
 def send_custom_message(self,message=None):
  pass
 def call_phone(self):
  pass
 def handle_picker(self,*items):
  instance=0
  for item in items:
   input_elem=self.ui.comp_picker_input.instance(instance)
   next_elem=input_elem.parent().child("android.widget.Button")
   first_text=input_elem.get_text()
   while True:
    current_text=input_elem.get_text()
    if current_text==str(item):
     break
    if first_text==str(item):
     raise NativeError(" not found")
   instance+=1
 def get_authorize_settings(self):
  ui_views=self.at.java_driver.dump_ui()
  setting_map={}
  for ui_view in ui_views:
   if ui_view.cls_name=="android.view.View" and ui_view.content_desc in["已开启","已关闭",]:
    check_status=True if ui_view.content_desc=="已开启" else False
    parant_view=ui_view.sibling().get_children()[0]
    setting_map[parant_view.text]=check_status
  return setting_map
 def back_from_authorize_setting(self):
  self.at.adb.press_back()
 def authorize_page_checkbox_enable(self,name,enable):
  setting_map=self.get_authorize_settings()
  if setting_map.get(name)==enable:
   return
  self.e.text(name).parent().instance(2).child().cls_name("android.view.View").click()
  if not enable:
   self.e.cls_name("android.widget.Button").text("关闭授权").click_if_exists(5)
 def release(self):
  self.at.release()
 def start_wechat(self):
  self.at.adb.start_app(WECHAT_PACKAGE,WECHAT_ACTIVITY)
 def stop_wechat(self):
  self.at.adb.stop_app(WECHAT_PACKAGE)
 def stop_get_perf(self):
  self.perf_flag=False
  self.perf_thread.join()
  self.pref_data_str+="]"
  if self.pref_data_str!="[]":
   pref_data_str=self.pref_data_str.replace(",]","]")
   return pref_data_str
  else:
   raise RuntimeError("get perf data fail")
 def write_perf_data(self,processname,timeinterval):
  while self.perf_flag:
   perf_cpu=self.at.adb.get_cpu_rate(processname)[processname]
   perf_mem=self.at.adb.get_mem_used(processname)[processname]
   tt1=time.time()
   tt1_json_data={tt1:{"cpu":perf_cpu,"mem":perf_mem}}
   self.pref_data_str+=json.dumps(tt1_json_data)+","
   time.sleep(timeinterval)
 def start_get_perf(self,timeinterval=15):
  processname=self.at.adb.get_current_process_appbrand()
  print(processname)
  if not processname:
   raise RuntimeError("current activity is not appbrand")
  try:
   self.perf_flag=True
   self.pref_data_str="["
   self.perf_thread=threading.Thread(target=self.write_perf_data,args=(processname,timeinterval))
   self.perf_thread.daemon=True
   self.perf_thread.start()
  except:
   return None
 def start_get_fps(self,timeinterval=1):
  self.fps_flag=True
  self.at.adb.clearbuffer()
  curview=self.at.adb.get_current_view_appbrand()
  if not curview:
   return None
  try:
   self.fps_thread=threading.Thread(target=self.count_fps_data,args=(curview,timeinterval))
   self.fps_thread.setDaemon(True)
   self.fps_thread.start()
  except Exception as e:
   print(e)
 def count_fps_data(self,curview,timeinterval):
  fps_index=-1
  while self.fps_flag:
   fps_index+=1
   fps_data=True
   fps_lines=self.at.adb.get_fps(curview)
   if len(fps_lines)<128:
    raise RuntimeError("current activity is not appbrand")
   for line in fps_lines:
    if line.count("0\t0\t0")!=0:
     fps_data=False
     break
   if not fps_data:
    time.sleep(timeinterval)
   else:
    fps_data_lines=[line.split("	")for line in fps_lines]
    end_timestamp=fps_data_lines[len(fps_data_lines)-1][1]
    start_timestamp=fps_data_lines[len(fps_data_lines)-127][1]
    time_period=(float(end_timestamp)-float(start_timestamp))/10**9
    refresh_period=int(fps_data_lines[0][0])
    jank_count=0
    for fps_data_index in range(1,len(fps_data_lines)):
     jank_prob=(int(fps_data_lines[fps_data_index][2])-int(fps_data_lines[fps_data_index][0]))/refresh_period
     if jank_prob>=1:
      jank_count+=1
    fps_data=int(126/time_period)
    if fps_data!=0:
     self.fps_data_dict[fps_index]=fps_data
    if jank_count!=0:
     self.jank_count_dict[fps_index]=jank_count
    time.sleep(timeinterval)
 def stop_get_fps(self):
  self.fps_flag=False
  self.fps_thread.join()
  if len(self.fps_data_dict)!=0:
   fps_data_arr=list(self.fps_data_dict.values())
   fps_max=max(fps_data_arr)
   fps_min=min(fps_data_arr)
   fps_avg=int(sum(fps_data_arr)/len(fps_data_arr))
   get_fps_result={"fps_max":fps_max,"fps_min":fps_min,"fps_avg":fps_avg,"fpsvalue":self.fps_data_dict,"jankvalue":self.jank_count_dict,}
   return json.dumps(get_fps_result)
  else:
   raise RuntimeError("get fps data fail")
 @property
 def e(self):
  return self.at.e
if __name__=="__main__":
 n=WXAndroidNative({"lang":"en"})
 n.handle_modal("queding","")
# Created by pyminifier (https://github.com/liftoff/pyminifier)
