#!/usr/bin/env python3
import os.path
import datetime
import time
from.log_color import*
import minium
from.assertbase import AssertBase
import minium.native
import minium.miniprogram.base_driver.minium_log
import json
import matplotlib.pyplot as plt
logger=logging.getLogger()
g_minium=None
g_native=None
g_log_message_list=[]
def full_reset():
 global g_minium,g_native
 if g_minium:
  reset_minium()
 if g_native:
  g_native.stop_wechat()
  g_native.release()
  g_native=None
def reset_minium():
 global g_minium
 g_minium.shutdown()
 g_minium.connection.remove_all_observers()
 g_minium.connection.destroy()
 g_minium=None
def get_native(cfg):
 global g_native
 if g_native is None:
  g_native=minium.native.get_native_driver(cfg.platform,cfg)
  g_native.start_wechat()
 return g_native
def get_minium(cfg):
 global g_minium,g_native
 if g_minium is None:
  g_minium=minium.miniprogram.get_minium_driver(conf=cfg)
  if not cfg.use_push and cfg.platform!="ide":
   g_native.connect_weapp(g_minium.qr_code)
   g_minium.connection.wait_for(method="App.initialized")
  if cfg.enable_app_log:
   g_minium.connection.register("App.logAdded",mini_log_added)
   g_minium.app.enable_log()
 return g_minium
def mini_log_added(message):
 dt=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
 message["dt"]=dt
 g_log_message_list.append(message)
class MiniTest(AssertBase):
 mini=None
 native=None
 log_message_list=[]
 @classmethod
 def setUpClass(cls):
  logger.debug("=====================")
  logger.debug("Testing class：%s"%cls.__name__)
  logger.debug("=====================")
  super(MiniTest,cls).setUpClass()
  if not cls.CONFIG.report_usage:
   minium.miniprogram.base_driver.minium_log.existFlag=1
  cls.native=get_native(cls.CONFIG)
  if cls.CONFIG.only_native:
   logger.info(f"Only native: {cls.CONFIG.only_native}, setUpClass complete")
   return
  cls.mini=get_minium(cls.CONFIG)
  cls.app=cls.mini.app
  cls.DEVICE_INFO["system_info"]=cls.mini.get_system_info()
 @classmethod
 def tearDownClass(cls):
  if cls.CONFIG.full_reset:
   logger.info("full reset")
   full_reset()
   return
  if g_minium and cls.CONFIG.close_ide and cls.CONFIG.platform!="ide":
   logger.info()
   reset_minium()
 def setUp(self):
  logger.debug("=========Current case：%s========="%self._testMethodName)
  super(MiniTest,self).setUp()
  if self.test_config.only_native:
   logger.info(f"Only native: {self.test_config.only_native}, setUp complete")
   return
  if self.test_config.auto_relaunch:
   self.app.go_home()
  if self.test_config.platform!="ide":
   if not self.native.handle_modal(btn_text="确定",title="本地调试已结束"):
    self.native.handle_modal(btn_text="OK",title="Local debugging ended")
  self.capture("setup")
 def tearDown(self):
  global g_log_message_list
  try:
   weapp_path="weapp.log"
   weapp_filename=self.wrap_filename(weapp_path)
   log_messages=g_log_message_list
   g_log_message_list=[]
   with open(weapp_filename,"w")as f:
    for log_message in log_messages:
     f.write(json.dumps(log_message,ensure_ascii=False)+"\n")
   self.results["weapp_log_path"]=weapp_path
   self.capture("teardown")
   self.results["page_data"]=self.page.data
  except:
   self.results["page_data"]=None
  super(MiniTest,self).tearDown()
 @property
 def page(self)->minium.Page:
  return self.mini.app.get_current_page()
 def capture(self,name):
  filename="%s.png"%datetime.datetime.now().strftime("%H%M%S%f")
  path=os.path.join(self.screen_dir,filename)
  if self.CONFIG.platform=="ide":
   self.mini.app.screen_shot(path)
  else:
   self.native.screen_shot(path)
  if os.path.exists(path):
   self.add_screen(name,path,self.page.path)
  else:
   logger.warning("%s not exists",path)
  return path
 def capture_fps_data(self,fps_str=""):
  fpsdata_path="fpsdata.json"
  fpsdata_filename=self.wrap_filename(fpsdata_path)
  fpspic_path="fpsdatapic.png"
  fpspic_filename=os.path.join(self.screen_dir,fpspic_path)
  if fps_str=="":
   return False
  with open(fpsdata_filename,"w")as f:
   f.write(fps_str)
  f.close()
  fps_data=json.loads(fps_str)
  fps_max=fps_data["fps_max"]
  fps_min=fps_data["fps_min"]
  fps_avg=fps_data["fps_avg"]
  fpsvalue=fps_data["fpsvalue"]
  jankvalue=fps_data["jankvalue"]
  plt.clf()
  plt.subplots_adjust(wspace=0,hspace=0.4) 
  plt.subplot(211,facecolor="#333744")
  plt.xlabel("time(s)",color="c")
  plt.ylabel("fps",color="peachpuff")
  plt.legend(title="fps_max:%s fps_min:%s fps_average:%s"%(fps_max,fps_min,fps_avg),loc="lower left",fontsize="small",)
  plt.plot(list(fpsvalue.keys()),list(fpsvalue.values()),marker="^",linewidth=1.0,color="C4",)
  plt.subplot(212,facecolor="#333744")
  plt.xlabel("time(s)",color="c")
  plt.ylabel("jank num",color="peachpuff")
  plt.scatter(list(jankvalue.keys()),list(jankvalue.values()),s=80,marker="*")
  if len(jankvalue)==0:
   plt.legend(title="no jank,very good",loc="lower left",fontsize="small")
  plt.savefig(fpspic_filename,dpi=120,facecolor="#333744")
  if os.path.exists(fpspic_filename):
   self.add_screen(fpspic_path,fpspic_filename,self.page.path)
  else:
   logger.warning("%s not exists",fpspic_filename)
  return fpspic_filename
 def capture_perf_data(self,perf_arr_str=""):
  weapp_path="perfdata.json"
  weapp_filename=self.wrap_filename(weapp_path)
  perfpic_path="perfdatapic.png"
  perfpic_filename=os.path.join(self.screen_dir,perfpic_path)
  if perf_arr_str=="":
   return False
  with open(weapp_filename,"w")as f:
   f.write(perf_arr_str)
  f.close()
  perf_arr=json.loads(perf_arr_str)
  perf_data_timestamp_arr=[]
  perf_data_cpu_arr=[]
  perf_data_mem_arr=[]
  if len(perf_arr)==0:
   return False
  for perf_data in perf_arr:
   perf_data_timestamp=list(perf_data.keys())[0]
   perf_data_time=int(perf_data_timestamp.split(".")[0])
   perf_data_cpu=perf_data[perf_data_timestamp]["cpu"]
   perf_data_mem=perf_data[perf_data_timestamp]["mem"]
   perf_data_timestamp_arr.append(perf_data_time)
   perf_data_cpu_arr.append(perf_data_cpu)
   perf_data_mem_arr.append(perf_data_mem)
  perf_data_timestamp_arr=[x-perf_data_timestamp_arr[0]for x in perf_data_timestamp_arr]
  plt.clf()
  plt.subplots_adjust(wspace=0,hspace=0.4) 
  plt.subplot(211,facecolor="#333744")
  plt.xlabel("time(s)",color="c")
  plt.ylabel("CPU Usage",color="peachpuff")
  plt.plot(perf_data_timestamp_arr,perf_data_cpu_arr,marker="^",linewidth=1.0,color="C4",)
  plt.subplot(212,facecolor="#333744")
  plt.xlabel("time(s)",color="c")
  plt.ylabel("Memory Usage",color="peachpuff")
  plt.plot(perf_data_timestamp_arr,perf_data_mem_arr,marker="*",linewidth=1.0,color="C4",)
  plt.savefig(perfpic_filename,dpi=120,facecolor="#333744")
  if os.path.exists(perfpic_filename):
   self.add_screen(perfpic_path,perfpic_filename,self.page.path)
  else:
   logger.warning("%s not exists",perfpic_filename)
  return perfpic_filename
 def assertPageData(self,data,msg=None):
  pass
 def assertContainTexts(self,texts,msg=None):
  pass
 def assertTexts(self,texts,selector="",msg=None):
  for text in texts:
   elem=self.page.get_element(selector,inner_text=text)
   if elem is None:
    raise AssertionError("selector:%s, inner_text=%s not Found")
 def hook_assert(self,name,ret,reason=None):
  if self.test_config.assert_capture:
   self.capture("{0}-{1}".format(name,"success" if ret else "failed"))
# Created by pyminifier (https://github.com/liftoff/pyminifier)
