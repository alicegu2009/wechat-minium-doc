#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import minium
import logging.handlers
import json
import os
from minium.framework import report
from multiprocessing import Process,Queue
from queue import Empty
from.minisuite import MiniSuite
from minium.framework import minitest
from.miniconfig import MiniConfig
logger=logging.getLogger("SESSION")
FILENAME_SUMMARY="summary.json"
class Session(Process):
 def __init__(self,conf:dict,queue:Queue,generate_report:bool=False):
  super(Session,self).__init__()
  self.port=conf.get("port")
  self.nick_name=conf.get("account_info",{}).get("wx_nick_name",None)
  self.open_id=conf.get("account_info",{}).get("open_id",None)
  self.device_id=(conf.get("device_desire",{}).get("device_info",{}).get("udid",None))
  if self.device_id is None:
   self.device_id=(conf.get("device_desire",{}).get("device_info",{}).get("serial",None))
  self.os_type=conf.get("platform")
  self.platform=conf.get("app")
  self.conf=json.dumps(conf)
  self.queue=queue
  self.mini=None
  self.native=None
  self.generate_report=generate_report
 def run(self)->None:
  minitest.AssertBase.CONFIG=MiniConfig(json.loads(self.conf))
  minitest.AssertBase.setUpConfig()
  while True:
   try:
    tests=self.queue.get(timeout=10)
    result=self.run_case(tests=tests)
    summary_path=os.path.join(minitest.AssertBase.CONFIG.outputs,FILENAME_SUMMARY)
    result.dumps(summary_path)
    if self.generate_report:
     report.imp_main(minitest.AssertBase.CONFIG.outputs)
   except Empty:
    logger.info(f"case queue is empty, test complete, release {self.device_id}")
    break
   except Exception as e:
    logger.exception(e)
 @staticmethod
 def run_case(tests):
  mini_suite=MiniSuite()
  result=minium.MiniResult(mini_suite)
  tests.run(result)
  result.print_shot_msg()
  return result
# Created by pyminifier (https://github.com/liftoff/pyminifier)
