from __future__ import absolute_import
from.auth import PrivateKeyAuth,OAuthToken
from.client import TgitClient
__version__="1.1"
# Created by pyminifier (https://github.com/liftoff/pyminifier)
