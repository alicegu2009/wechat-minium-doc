import requests
class PrivateKeyAuth(requests.auth.AuthBase):
 def __init__(self,private_key):
  self.private_key=private_key
 def __call__(self,r):
  r.headers["PRIVATE-TOKEN"]=self.private_key
  return r
class OAuthToken(requests.auth.AuthBase):
 def __init__(self,oauth_token):
  self.oauth_token=oauth_token
 def __call__(self,r):
  r.headers["OAUTH-TOKEN"]=self.oauth_token
  return r
# Created by pyminifier (https://github.com/liftoff/pyminifier)
