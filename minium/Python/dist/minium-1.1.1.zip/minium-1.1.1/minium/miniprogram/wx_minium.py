#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@Author: lockerzhang
@LastEditors: lockerzhang
@Description: client 入口
@Date: 2019-03-11 14:42:52
@LastEditTime: 2019-06-05 15:05:04
"""
import platform
import os
import base64
import json
import re
from websocket import WebSocketConnectionClosedException
from .base_driver.app import App
from .base_driver.connection import Connection
from .base_driver.minium_object import MiniumObject
from ..framework.miniconfig import MiniConfig, get_log_level
from ..framework.exception import *
from ..native import get_native_driver

LOG_FORMATTER = (
    "%(levelname)-5.5s %(asctime)s %(filename)-10s %(funcName)-15s %(lineno)-3d %(message)s"
)

MAC_DEVTOOL_PATH = "/Applications/wechatwebdevtools.app/Contents/MacOS/cli"
WINDOWS_DEVTOOL_PATH = "C:/Program Files (x86)/Tencent/微信web开发者工具/cli.bat"
TEST_PORT = 9420
UPLOAD_URL = "https://stream.weixin.qq.com/weapp/UploadFile"

# source_path是存放资源文件的路径
cur_path = os.path.dirname(os.path.realpath(__file__))
resource_path = os.path.join(os.path.dirname(cur_path), "wx_resources")
if not os.path.exists(resource_path):
    os.mkdir(resource_path)


class LogLevel(object):
    INFO = 20
    DEBUG_SEND = 12
    METHOD_TRACE = 11
    DEBUG = 9


def build_version():
    config_path = os.path.join(os.path.dirname(__file__), "version.json")
    if not os.path.exists(config_path):
        return {}
    else:
        with open(config_path, "rb") as f:
            version = json.load(f)
            return version


class WXMinium(MiniumObject):
    """
    自动化入口
    """

    def __init__(self, conf: MiniConfig = None, uri="ws://localhost", native=None, **kwargs):
        """
        初始化
        :param uri: WebSocket 地址
        :param conf: 配置
        :param native: native实例
        """
        super().__init__()
        if not conf:
            conf = MiniConfig()
        elif isinstance(conf, dict):
            conf = MiniConfig(conf)
        self.conf = conf
        self.logger.setLevel(get_log_level(conf.debug_mode))
        if native is None and conf.device_desire and conf.platform:
            self.native = get_native_driver(conf.platform, conf)
        else:
            self.native = native
        self.version = build_version()
        self.sdk_version = None
        self.platform = "devtools"  # devtools, android, ios
        self.logger.info(self.version)
        self.start_cmd = ""
        self.app = None
        self.connection = None
        test_port = str(conf.test_port) if conf.get("test_port", None) else str(TEST_PORT)
        self.uri = uri + ":" + test_port
        self.test_port = test_port
        self.open_id = conf.get("account_info", {}).get("open_id", None)
        self.ticket = conf.get("account_info", {}).get("ticket", None)
        self.project_path = conf.get("project_path", None)
        self.is_remote = False

        self._is_windows = "Windows" in platform.platform()
        if conf.get("dev_tool_path", None):
            if self._is_windows and not (
                conf.dev_tool_path.endswith("cli") or conf.dev_tool_path.endswith("cli.bat")
            ):
                raise Exception(
                    "[dev_tool_path] is not correct, it's usually named as 'cli' or 'cli.bat'"
                )
            self.dev_tool_path = conf.dev_tool_path
        elif "Darwin" in platform.platform() or "macOS" in platform.platform():
            self.dev_tool_path = MAC_DEVTOOL_PATH
        elif self._is_windows:
            self.dev_tool_path = WINDOWS_DEVTOOL_PATH
        else:
            self.logger.warning("Dev tool doesn't support current OS yet")

        self.launch_dev_tool()

        if conf.get("platform", None) != "ide":
            path = self.enable_remote_debug(
                use_push=conf.get("use_push", True),
                connect_timeout=conf.get("remote_connect_timeout", 180),
            )
            self.qr_code = path

    def __del__(self):
        self.native = None

    def __getattr__(self, name):
        """
        当minium中方法不存在且native中存在，返回native的方法
        """
        if self.native:
            item = getattr(self.native, name)
            if callable(item):
                return item
        raise AttributeError("'%s' object has no attribute '%s'" % (self.__class__.__name__, name))

    def _dev_cli(self, cmd, input=b""):
        if not self.dev_tool_path or not os.path.exists(self.dev_tool_path):
            raise MiniConfigError("dev_tool_path: %s not exists" % self.dev_tool_path)
        if self._is_windows:
            cmd_template = '"%s"  %s'
        else:
            cmd_template = "%s %s"
        # do_shell 返回 output & error, 但是，实际上cli命令out返回的是error message, err返回的是output message
        err, out = self._do_shell(cmd_template % (self.dev_tool_path, cmd), input=input)
        if err:
            # error like:
            # [error] {
            #   code: 10,
            #   message: 'Error: 错误 Error: Port 9422 is in use (code 10)Error: Port 9422 is in use\n' +
            #     '    at Object.exports.auto [as method] (/Applications/wechatwebdevtools.app/Contents/Resources/package.nw/core.wxvpkg/1d3c44fb45826718b091c4f56f6d9ab0.js:2:925)\n' +
            #     '    at processTicksAndRejections (node:internal/process/task_queues:93:5)\n' +
            #     '    at async /Applications/wechatwebdevtools.app/Contents/Resources/package.nw/core.wxvpkg/7a975443f52e91830ae1d65cdf8c86db.js:2:3593\n' +
            #     '    at async Object.<anonymous> (/Applications/wechatwebdevtools.app/Contents/Resources/package.nw/core.wxvpkg/7a975443f52e91830ae1d65cdf8c86db.js:2:2983)'
            # }
            reg = re.search(
                r"(\[error\]\s*{\s*code:\s*(\d+),\s*message:.*(Error:.*\(code\s\d+\)))", err, re.M
            )
            if reg:
                # 提取message信息返回
                return reg.group(3)
            return err
        return

    def _get_sdk_version(self):
        # read from project.config.json
        if self.project_path and os.path.isfile(
            os.path.join(self.project_path, "project.config.json")
        ):
            with open(os.path.join(self.project_path, "project.config.json"), "r") as fd:
                self.sdk_version = json.loads(fd.read().strip()).get("libVersion", None)

    def _comp_version(self, a: str, b: str) -> int:
        """
        description:
        param {*} self
        param {str} a
        param {str} b
        return {int} 1 if a > b, 0 if a == b ,-1 if a < b
        """
        i = 0
        a = a.split(".")
        b = b.split(".")
        while i < len(a) and i < len(b):
            if int(a[i]) > int(b[i]):
                return 1
            elif int(a[i]) < int(b[i]):
                return -1
            i += 1
        return 0

    def _get_system_info(self):
        """
        description: 获取当前系统信息，更新platform/sdk_version
        param {*} self
        return {*}
        """
        try:
            system_info = self.get_system_info()
        except MiniTimeoutError:
            # 命令没响应，应该是基础库版本问题
            if self.sdk_version is not None and self._comp_version(self.sdk_version, "2.7.3") == -1:
                raise MiniLaunchError("基础库版本[%s]过低，请确认基础库版本>=2.7.3" % self.sdk_version)
            raise
        self.sdk_version = system_info.get("SDKVersion", self.sdk_version)
        self.platform = system_info.get("platform", "devtools").lower()

    def launch_dev_tool(self):
        # start dev tool with minium model
        self.logger.info("Starting dev tool and launch MiniProgram project ...")
        is_port_in_use = False
        if self.project_path:
            if not os.path.exists(self.project_path):
                raise MiniConfigError("project_path: %s not exists" % self.project_path)
            if not os.path.isdir(self.project_path):
                raise MiniConfigError("project_path: %s is not directory" % self.project_path)
            if not os.path.isfile(os.path.join(self.project_path, "project.config.json")):
                raise MiniConfigError(
                    "can't find project.config.json in %s, please confirm the directory contains"
                    " miniproject project"
                    % self.project_path
                )
            # launch失败可能与基础库相关，先记录项目配置的基础库版本
            self._get_sdk_version()
            # config start cmd
            self.start_cmd = "auto --project %s --auto-port %s" % (
                self.project_path,
                self.test_port,
            )
            if self.open_id:
                self.start_cmd += f" --auto-account {self.open_id}"
            elif self.ticket:
                self.start_cmd += f" --test-ticket {self.ticket}"
            # run cmd
            err_msg = self._dev_cli(self.start_cmd, input=b"y")
            if err_msg:
                # launch error
                if "Port %s is in use" % self.test_port in err_msg:
                    # 开发者工具可能已经打开并占用了测试端口, 可直接尝试连接
                    is_port_in_use = True
                else:
                    # 其他错误直接报错看看什么问题
                    raise MiniLaunchError(err_msg)
            else:
                # launch success, wait ide init
                if self._is_windows:
                    # windows更卡
                    time.sleep(10)
                else:
                    time.sleep(5)
        else:
            self.start_cmd = None
            self.logger.warning(
                "Can not find `project_path` in config, that means you must open dev tool by"
                " automation way first"
            )
            self.logger.warning(
                "If you are not running command like [cli auto --project /path/to/project"
                " --auto-port 9420], you may config `project_path` or run this command first"
            )
            err_msg = None
        try:
            self.connect_dev_tool()
            return
        except MiniConnectError as e:
            # ws连接不上
            self.logger.error(f"{str(e)}, restart now...")
            if is_port_in_use:
                # 端口被占用，先尝试关掉项目再重试
                if self.connection:
                    self.connection.send("Tool.close")
                elif "--auto-account" not in self.start_cmd:
                    self._dev_cli(f"close --project {self.project_path}")
                else:
                    raise MiniLaunchError(
                        "In the case with multi-account mode and no connection with dev tool,"
                        " please close devtools by your self"
                    )
                time.sleep(5)
            if self.start_cmd:  # 重启一次
                self.logger.info("Starting dev tool again...")
                err_msg = self._dev_cli(self.start_cmd, input=b"y")
                if err_msg:
                    raise MiniLaunchError(err_msg)
                else:
                    self.logger.info("Restart success")
                    # launch success, wait ide init
                    if self._is_windows:
                        # windows更卡
                        time.sleep(10)
                    else:
                        time.sleep(5)
                self.connect_dev_tool()
                return
            raise e
        except MiniLaunchError:
            # 初始化app error
            raise

    def connect_dev_tool(self):
        i = 3
        while i:
            try:
                self.logger.info("Trying to connect Dev tool ...")
                connection = Connection(self.uri, timeout=self.conf.get("request_timeout"))
                self.connection = connection
                self._get_system_info()
                self.app = App(
                    connection,
                    self.conf.get("auto_relaunch"),
                    native=self.native,
                    platform=self.platform,
                )
            except MiniLaunchError:
                raise
            except Exception as e:
                self.logger.exception(e)
                i -= 1
                if i == 0:
                    raise MiniConnectError("three times try to connect Dev tool has all fail ...")
                continue
            else:
                break
        return True

    def launch_dev_tool_with_login(self):
        # login first
        if not self.dev_tool_path or not os.path.exists(self.dev_tool_path):
            raise MiniConfigError("dev_tool_path: %s not exists" % self.dev_tool_path)
        if self._is_windows:
            cmd_template = '"%s"  login'
        else:
            cmd_template = "%s login"
        # 需要输出二维码，所以直接用os.system就好了
        ret = os.system(cmd_template % self.dev_tool_path)
        if ret == 0:
            return self.launch_dev_tool()

    def get_app_config(self):
        """
        获取 app 的配置
        :return: object
        """
        return (
            self.evaluate("function () {return __wxConfig}", sync=True)
            .get("result", {"result": {}})
            .get("result", None)
        )

    def get_system_info(self):
        """
        获取系统信息
        :return:
        """
        return (
            self.call_wx_method("getSystemInfoSync")
            .get("result", {"result": {}})
            .get("result", None)
        )

    def enable_remote_debug(self, use_push=True, path=None, connect_timeout=180):
        self.reset_remote_debug()
        time.sleep(2)
        if use_push:
            retry_times = 3
            while retry_times > 0:
                try:
                    self.logger.info(f"Enable remote debug, for the {4 - retry_times}th times")
                    self.connection.send(
                        "Tool.enableRemoteDebug",
                        params={"auto": True},
                        max_timeout=connect_timeout,
                    )
                    self.is_remote = True
                except Exception as e:
                    retry_times -= 1
                    self.logger.error("enable remote debug fail ...")
                    self.logger.error(e)
                    if retry_times == 0:
                        self.logger.error(
                            "Enable remote debug has been fail three times. Please check your"
                            " network or proxy effective or not "
                        )
                        raise
                    continue
                else:
                    retry_times -= 1
                    rtn = self.connection.wait_for(
                        method="App.initialized", max_timeout=connect_timeout
                    )
                    if retry_times == 0 and rtn is False:
                        self.logger.error(
                            "Wait for APP initialized has been fail three times. Please check your"
                            " phone's current foreground APP is WeChat or not, and check"
                            " miniProgram has been open or not "
                        )
                        raise MiniLaunchError("Launch APP Error")
                    if rtn is True:
                        break
                    else:
                        # 等不到App.initialized一般就是白屏，通道不通，exit会报错，跳出重试，需要catch
                        try:
                            self.app.exit()
                        except MiniTimeoutError:
                            # 白屏的时候切换一下扫码编译，有时会有意想不到效果
                            self.connection.send(
                                "Tool.enableRemoteDebug", max_timeout=connect_timeout
                            )
            # 远程调试开启成功后，小程序运行态已经转到手机，需要重新实例化app
            self._get_system_info()
            self.app = App(
                self.connection,
                self.conf.get("auto_relaunch"),
                native=self.native,
                platform=self.platform,
            )
            return None
        if path is None:
            path = os.path.join(resource_path, "debug_qrcode.jpg")
        qr_data = self.connection.send(
            "Tool.enableRemoteDebug", max_timeout=connect_timeout
        ).result.qrCode
        with open(path, "wb") as qr_img:
            qr_img.write(base64.b64decode(qr_data))

        return path

    def reset_remote_debug(self):
        """
        重置远程调试，解决真机调试二维码扫码界面报-50003 等常见错误
        :return:
        """
        return self.connection.send("Tool.resetRemoteDebug")

    def clear_auth(self):
        """
        清除用户授权信息. 公共库 2.9.4 开始生效
        :return:
        """
        if self.conf.mock_native_modal and self.conf.platform == "ide":  # 对授权弹窗MOCK了，需要清除MOCK信息
            self.evaluate("""function() {global.mini_auth_setting = {}}""")
        self.connection.send("Tool.clearAuth")

    def get_test_accounts(self):
        """
        获取已登录的真机账号
        :return: list [{openid, nickName}]
        """
        return self.connection.send("Tool.getTestAccounts").result.accounts

    def shutdown(self):
        """
        关闭 Driver, 释放native引用
        :return: status
        """
        if getattr(self.native, "mini", None):
            self.native.mini = None  # IDE native借用minium通信通道交互
        self.native = None
        try:
            if self.is_remote:
                self.logger.info("MiniProgram closing")
                self.app.exit()
            self.logger.info("Project window closing")
            self.connection.send("Tool.close")
            self._wait(lambda: not self.connection._is_connected, 5, 1)
        except (MiniTimeoutError, MiniAppError) as e:
            self.logger.exception(f"Shutdown Excrption:{e}")

    def release(self):
        """
        释放所有资源, 不允许在case中调用
        :return: None
        """
        # 释放native
        if getattr(self.native, "mini", None):
            self.native.mini = None  # IDE native借用minium通信通道交互
        self.native = None
        # 释放app
        if self.is_remote:
            try:
                self.logger.info("MiniProgram closing")
                self.app.exit()
            except (
                MiniTimeoutError,
                MiniAppError,
                WebSocketConnectionClosedException,
            ) as e:
                self.logger.exception(f"Close app excrption:{e}")
            finally:
                if self.app is not None:
                    self.app.native = None
                    self.app = None
        # 释放connection
        try:
            self.connection.send_async("Tool.close")
        except WebSocketConnectionClosedException:
            pass
        finally:
            if self._wait(lambda: not self.connection._is_connected, 5, 1):  # already closed
                self.connection.remove_all_observers()
            else:
                self.connection.destroy()


if __name__ == "__main__":

    mini = WXMinium()
