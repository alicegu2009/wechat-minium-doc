#!/usr/local/bin/python3
# -*- coding: utf-8 -*-
"""
Author:         lockerzhang
Filename:       minium_object.py
Create time:    2019/4/30 21:21
Description:

"""

from .minium_log import MonitorMetaClass
import subprocess
import time
from functools import wraps
import logging

logger = logging.getLogger()


def timeout(duration):
    """
    重试超时装饰器，在超市之前会每隔一秒重试一次
    注意：被修饰的函数必须要有非空返回，这是重试终止的条件！！！
    :param duration: seconds
    :return:
    """

    def spin_until_true(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            timeout = time.time() + duration
            r = func(*args, **kwargs)
            while not r:
                time.sleep(1)
                if timeout < time.time():
                    logger.warning("timeout for %s" % func.__name__)
                    break
                r = func(*args, **kwargs)
            return r

        return wrapper

    return spin_until_true


class MiniumObject(object, metaclass=MonitorMetaClass):
    def __init__(self):
        self.logger = logger
        self.observers = {}
        self.connection = None

    def _do_shell(self, command, print_msg=True, input=b""):
        """
        执行 shell 语句
        :param command:
        :param print_msg:
        :return:
        """
        self.logger.info("de shell: %s" % command)
        p = subprocess.Popen(
            command,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            stdin=subprocess.PIPE,
        )
        out, err = p.communicate(input)
        try:
            out = out.decode("utf8")
        except UnicodeDecodeError:
            out = out.decode("gbk")
        try:
            err = err.decode("utf8")
        except UnicodeDecodeError:
            err = err.decode("gbk")
        if print_msg:
            self.logger.info("err:\n%s" % err)
            self.logger.info("out:\n%s" % out)
        return out, err

    def call_wx_method(self, method, args=None):
        """
        调用 wx 的方法
        :param method:
        :param args:
        :return:
        """
        return self._call_wx_method(method=method, args=args)

    def mock_wx_method(
        self,
        method,
        functionDeclaration: str = None,
        result=None,
        args=None,
        success=True,
    ):
        """
        mock wx method and return result
        :param self:
        :param method:
        :param functionDeclaration:
        :param result:
        :param args:
        :param success:
        :return:
        """
        self._mock_wx_method(
            method=method,
            functionDeclaration=functionDeclaration,
            result=result,
            args=args,
            success=success,
        )

    def restore_wx_method(self, method):
        """
        恢复被 mock 的方法
        :param method:
        :return:
        """
        self.connection.send("App.mockWxMethod", {"method": method})

    def hook_wx_method(self, method, before=None, after=None, callback=None):
        """
        hook wx 方法
        :param method: 需要 hook 的方法
        :param before: 在需要 hook 的方法之前调用
        :param after: 在需要 hook 的方法之后调用
        :param callback: 在需要 hook 的方法回调之后调用
        :return:
        """

        def super_before(msg):
            self.logger.debug(f"{method} before hook result: {msg['args']}")
            if before:
                before(msg["args"])

        if before and not callable(before):
            self.logger.error(f"wx.{method} hook before method is non-callable")
            return
        if before:
            self._expose_function(method + "_" + super_before.__name__, super_before)

        def super_after(msg):
            self.logger.debug(f"wx.{method} after hook result: {msg['args']}")
            if after:
                after(msg["args"])

        if after and not callable(after):
            self.logger.error(f"{method} hook after method is non-callable")
            return
        if after:
            self._expose_function(method + "_" + super_after.__name__, super_after)

        def super_callback(msg):
            self.logger.debug(f"wx.{method} callback hook result: {msg['args']}")
            if callback:
                callback(msg["args"])

        if callback and not callable(callback):
            self.logger.error(f"{method} hook callback method is non-callable")
            return
        if callback:
            self._expose_function(method + "_" + super_callback.__name__, super_callback)

        self.evaluate(
            """function () {
    var origin = wx.%(method)s;
    if(!wx.%(origin)s){
        Object.defineProperty(wx, "%(origin)s", {
            configurable:true,
            get() {
                return origin;
            }
        })
    }
    Object.defineProperty(wx, "%(method)s", {
        configurable:true,
        get() {
            return function (...args) {
                var obj = args[0];
                var use_promise = false;
                if (!"%(method)s".endsWith("Sync") && (!obj || (!obj.success && !obj.fail && !obj.complete))){
                    use_promise = true;
                }
                typeof(%(before)s) !== "undefined" && %(before)s(...args);
                var res;
                if (typeof(%(callback)s) !== "undefined") {
                    if (use_promise) {
                        res = origin(...args).then(function (data) {
                            %(callback)s(data)
                            return data
                        })
                    }
                    else {
                        if(obj) {
                            var complete = obj.complete;
                            obj.complete = function (res) {
                                %(callback)s(res)
                                complete && complete(res)
                            }
                        }
                        res = origin(...args);
                    }
                } else {
                    res = origin(...args);
                }
                typeof(%(after)s) !== "undefined" && %(after)s(res);
                return res
            }
        }
    })
    }"""
            % (
                dict(
                    method=method,
                    origin=method + "_MiniumOrigin",
                    before=method + "_" + super_before.__name__,
                    after=method + "_" + super_after.__name__,
                    callback=method + "_" + super_callback.__name__,
                )
            ),
            sync=True,
        )

    def release_hook_wx_method(self, method):
        """
        释放 hook wx 方法
        :param method: 需要释放 hook 的方法
        :return:
        """
        self.evaluate(
            """function () {
    var origin = wx.%(origin)s;
    if(origin && origin != wx.%(method)s){
        Object.defineProperty(wx, "%(method)s", {
            get() {
                return origin;
            }
        })
    };
    (typeof(%(before)s) !== "undefined") && (%(before)s = undefined);
    (typeof(%(after)s) !== "undefined") && (%(after)s = undefined);
    (typeof(%(callback)s) !== "undefined") && (%(callback)s = undefined);
    }"""
            % (
                dict(
                    origin=method + "_MiniumOrigin",
                    method=method,
                    before=method + "_super_before",
                    after=method + "_super_after",
                    callback=method + "_super_callback",
                )
            ),
            sync=True,
        )
        # 移除监听函数
        self.connection.remove(method + "_super_before")
        self.connection.remove(method + "_super_after")
        self.connection.remove(method + "_super_callback")

    def evaluate(self, app_function: str, args=None, sync=False):
        """
        向 app Service 层注入代码并执行
        :param app_function:
        :param args:
        :param sync:
        :return:
        """
        return self._evaluate(app_function=app_function, args=args, sync=sync)

    # protect method

    def hook_current_page_method(self, method, callback):
        """
        hook 当前页面的方法
        :param method:  方法名
        :param callback:    回调函数
        """

        def super_callback(msg):
            self.logger.debug(f"Page.{method} call hook result: {msg['args']}")
            if callback:
                callback(msg["args"])

        if callback and not callable(callback):
            self.logger.error(f"Page.{method} hook callback method is non-callable")
            return
        if callback:
            self._expose_function(
                "page_hook_" + method + "_" + super_callback.__name__, super_callback
            )
        self.evaluate(
            """function() {
            var current_page_instance = getCurrentPages().pop();
            if (current_page_instance["%(method)s"]) {
                var src = current_page_instance["%(method)s"];
                current_page_instance["%(method)s"] = (function(...args){
                    (typeof(%(callback)s) != "undefined") && %(callback)s(...args);
                    src.call(this, ...args);
                }).bind(current_page_instance);
            }
        }"""
            % (
                {
                    "method": method,
                    "callback": "page_hook_" + method + "_" + super_callback.__name__,
                }
            ),
            sync=True,
        )

    # private method

    def _wait(self, func, timeout, interval=1):
        """
        等待直到`func`为true
        :func: callable function
        :timeout: timeout
        :interval: query step
        :return: bool
        """
        # func = lambda :True or False
        if not callable(func):
            return False
        s = time.time()
        while time.time() - s < timeout:
            if func():
                return True
            time.sleep(interval)
        return False

    def _call_wx_method(self, method, args=None):
        if args is None:
            args = []
        if not isinstance(args, list):
            if isinstance(args, str):
                # 如果是字符型参数，就可以不用管是否是 sync 方法，直接转数组传参即可
                args = [args]
            elif "Sync" in method:
                # 如果是 sync 方法，则需要从字典里面提取所有的 value 成为一个数组进行传参
                if isinstance(args, dict):
                    temp_args = list()
                    for key in args.keys():
                        temp_args.append(args[key])
                    args = temp_args
            else:
                # 异步方法的话无需管 args 是str 还是 dict，直接转成 list 即可
                args = [args]

        params = {"method": method, "args": args}
        return self.connection.send("App.callWxMethod", params)

    def _evaluate(self, app_function: str, args=None, sync=False):
        if not args:
            args = []
        if sync:
            return self.connection.send(
                "App.callFunction", {"functionDeclaration": app_function, "args": args}
            )
        else:
            return self.connection.send_async(
                "App.callFunction", {"functionDeclaration": app_function, "args": args}
            )

    def _expose_function(self, name, binding_function):
        self.connection.register(name, binding_function)
        self.connection.send("App.addBinding", {"name": name})

    def _unregister(self, name, binding_function=None):
        self.connection.remove(name, binding_function)

    def _mock_wx_method(
        self, method, functionDeclaration: str, result=None, args=None, success=True
    ):
        if not args:
            args = []
        else:
            args = [args]
        callback_type = "ok" if success else "fail"
        if functionDeclaration:
            self.connection.send(
                "App.mockWxMethod",
                {
                    "method": method,
                    "functionDeclaration": functionDeclaration,
                    "args": args,
                },
            )
        else:
            if isinstance(result, str):
                self.connection.send(
                    "App.mockWxMethod",
                    {
                        "method": method,
                        "result": {
                            "result": result,
                            "errMsg": "%s:%s" % (method, callback_type),
                        },
                    },
                )
            elif isinstance(result, dict):
                self.connection.send("App.mockWxMethod", {"method": method, "result": result})
            else:
                self.logger.warning("mock wx method accept str or dict result only")
