#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import minium
import datetime
import logging.handlers
import unittest
import requests
import json
import os
from.miniresult import MiniResult
from minium.framework import report
from multiprocessing import Process
from minium.framework import case_inspect
from.minisuite import MiniSuite
from minium.framework import minitest
logger=logging.getLogger("SESSION")
FILENAME_SUMMARY="summary.json"
class Session(Process):
 def __init__(self,conf,task_id,case_server_address,generate_report):
  super(Session,self).__init__()
  self.port=conf.get("port")
  self.nick_name=conf.get("account_info",{}).get("wx_nick_name",None)
  self.open_id=conf.get("account_info",{}).get("open_id",None)
  self.device_id=(conf.get("device_desire",{}).get("device_info",{}).get("udid",None))
  if self.device_id is None:
   self.device_id=(conf.get("device_desire",{}).get("device_info",{}).get("serial",None))
  self.os_type=conf.get("platform")
  self.platform=conf.get("app")
  self.conf=conf
  self.task_id=task_id
  self.case_server_address=case_server_address
  self.case_list=list()
  self.mini=None
  self.native=None
  self.generate_report=generate_report
  self.log_message_list=[]
  minitest.AssertBase.CONFIG=conf
  minitest.AssertBase.setUpConfig()
 def run(self)->None:
  while True:
   if self.case_list is None or len(self.case_list)==0:
    self.case_list=self.get_case()
    if self.case_list is None or len(self.case_list)==0:
     logger.info("no new case, test end")
     break
   case=self.case_list.pop()
   try:
    result=self.run_case(case["module_name"],case["case_name"])
    self.report_case(case["module_name"],case["case_name"],result)
    summary_path=os.path.join(minitest.AssertBase.CONFIG.outputs,FILENAME_SUMMARY)
    result.dumps(summary_path)
   except Exception as e:
    case["retry"]+=1
    if case["retry"]==2:
     logger.error(f"{case['module_name']}.{case['case_name']} has been try 2 times, but all failed.")
     logger.error(f"reporting error reason: {str(e)}")
     self.report_case(case["module_name"],case["case_name"],str(e))
     continue
    self.case_list.append(case)
  if self.generate_report:
   report.imp_main(minitest.AssertBase.CONFIG.outputs)
  minitest.release_minium()
 def get_case(self):
  retry=3
  while retry>0:
   try:
    data=json.dumps({"task_id":str(self.task_id),"conditions":{"platform":self.platform,"os_type":self.os_type,},})
    rtn=requests.post(url=f"{self.case_server_address}/case_center/get_case_list",data=data,headers={"Content-Type":"application/json"},)
    if rtn.status_code==200:
     fail_reason=json.loads(rtn.text).get("reason",None)
     if fail_reason:
      logger.error(f"get case fail: {fail_reason}")
     cases=json.loads(json.loads(rtn.text).get("cases","[]"))
     if len(cases)>0:
      case_rtn=list()
      for case in cases:
       case["retry"]=0
       case_rtn.append(case)
      return case_rtn
     return cases
    else:
     retry-=1
     continue
   except Exception as e:
    retry-=1
    if retry==0:
     logger.exception(e)
    continue
  return None
 def run_case(self,module_name,case_name):
  tests=self._load_from_case_name(module_name,case_name)
  mini_suite=MiniSuite()
  result=minium.MiniResult(mini_suite)
  tests.run(result)
  result.print_shot_msg()
  return result
 def report_case(self,module_name,case_name,result):
  res=json.dumps(result.summary)if isinstance(result,MiniResult)else result
  data=json.dumps({"task_id":str(self.task_id),"module_name":module_name,"case_name":case_name,"nick_name":self.nick_name,"open_id":self.open_id,"device_id":self.device_id,"result":res,})
  rtn=requests.post(url=f"{self.case_server_address}/case_center/report_case_result",data=data,headers={"Content-Type":"application/json"},)
  logger.info(f"report case({module_name}.{case_name}): {rtn.status_code}:{rtn.reason}")
 def _mini_log_added(self,message):
  dt=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
  message["dt"]=dt
  self.log_message_list.append(message)
 def _load_from_case_name(self,pkg,case_name):
  logger.debug("=====================")
  logger.debug(f"Loading Case: {pkg}.{case_name}")
  logger.debug("=====================")
  loader=unittest.TestLoader()
  test_class=case_inspect.find_test_class(pkg,case_name)
  if test_class:
   return loader.loadTestsFromName(case_name,test_class)
  else:
   raise AssertionError("can't not find testcase %s in pkg %s"%(case_name,pkg))
# Created by pyminifier (https://github.com/liftoff/pyminifier)
