#!/usr/local/bin/python3
# -*- coding: utf-8 -*-
from..controllers.case_center import*
def get_routes():
 routes=[(r"/case_center/(\w+)",CaseCenter)]
 return routes
# Created by pyminifier (https://github.com/liftoff/pyminifier)
