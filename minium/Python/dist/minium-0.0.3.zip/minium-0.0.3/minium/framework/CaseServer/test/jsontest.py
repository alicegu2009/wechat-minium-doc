#!/usr/local/bin/python3
# -*- coding: utf-8 -*-
import json
if __name__=="__main__":
 json_str=[{"key":1},{"key":2},{"key":3}]
 data=json.dumps(json_str)
 s=json.loads(data)
 print(type(data))
# Created by pyminifier (https://github.com/liftoff/pyminifier)
