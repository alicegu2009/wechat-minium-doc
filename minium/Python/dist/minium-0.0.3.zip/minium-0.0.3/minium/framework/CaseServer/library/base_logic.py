#!/usr/local/bin/python3
# -*- coding: utf-8 -*-
import logging
logger=logging.getLogger()
class Response(dict):
 def __init__(self):
  super(Response,self).__init__()
 def __getattr__(self,name):
  try:
   return self[name]
  except KeyError:
   raise AttributeError(name)
class BaseLogic:
 app_id:int
 def __init__(self,**kwargs):
  self.result=dict()
  self.initialize(**kwargs)
 def initialize(self,**kwargs):
  pass
 def ok(self,rtn=0,**kwargs):
  self.result["rtn"]=rtn
  self.result.update(kwargs)
  return self.result
 def fail(self,reason=None,rtn=-1,**kwargs):
  self.result["rtn"]=rtn
  self.result["msg"]="failed"
  self.result["reason"]=reason
  self.result.update(kwargs)
  logger.error(kwargs)
  return self.result
# Created by pyminifier (https://github.com/liftoff/pyminifier)
