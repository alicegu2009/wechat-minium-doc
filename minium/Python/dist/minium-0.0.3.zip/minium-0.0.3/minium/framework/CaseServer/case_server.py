#!/usr/local/bin/python3
# -*- coding: utf-8 -*-
import platform
if platform.system()=="Windows":
 import asyncio
 from sys import version_info
 if version_info.major>=3 and version_info.minor>=8:
  asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
import tornado
import tornado.web
import tornado.httpserver
import argparse
from tornado.options import define,options
from.tools import*
from.config.path import*
add_sys_paths()
project_dir=os.path.dirname(os.path.abspath(__file__))
case_db_path=os.path.join(project_dir,"storage/case.db")
class CaseServer:
 def __init__(self):
  self.port=None
  self.ip=get_host_ip()
  pass
 def __del__(self):
  pass
 def read_config(self,config_file_path):
  define("svc_ip",type=str,default="0.0.0.0",help="The IP this service listen",metavar="IP",)
  define("svc_port",type=int,default=12380,help="The port this service listen",metavar="Port",)
  define("db_path",type=str,default=case_db_path,help="case database default path",)
  define("svc_name",type=str,default="case_server",help="The service name")
  define("max_proc_count",type=int,default=10,help="Max process count")
 def start_listener(self):
  from.config.routes import get_routes
  case_server=tornado.web.Application(get_routes())
  http_server=tornado.httpserver.HTTPServer(case_server,xheaders=True)
  http_server.bind(options.svc_port,options.svc_ip)
  options.max_proc_count=(1 if not hasattr(os,"fork")else options.max_proc_count)
  http_server.start(num_processes=options.max_proc_count)
  tornado.ioloop.IOLoop.instance().start()
 def start_service(self,port=None,db_path=None):
  self.read_config(os.path.join(project_dir,"config","case_server.conf"))
  options.svc_port=port if port else pick_unused_port()
  self.port=options.svc_port
  if db_path:
   options.db_path=db_path
  print(f"Case Server address:http://{self.ip}:{self.port}")
  self.start_listener()
def main():
 parsers=argparse.ArgumentParser()
 parsers.add_argument("-d","--database-path",dest="db_path",type=str,default=None,help="custom database path",)
 parsers.add_argument("-p","--port",dest="port",type=int,default=None,help="custom case service port",)
 parsers.format_help()
 parser_args=parsers.parse_args()
 CaseServer().start_service(port=parser_args.port,db_path=parser_args.db_path)
if __name__=="__main__":
 case_server=CaseServer()
 case_server.start_service()
# Created by pyminifier (https://github.com/liftoff/pyminifier)
