#!/usr/local/bin/python3
# -*- coding: utf-8 -*-
import json
from..library.base_handler import BaseHandler
from..logics.case_center_logic import CaseCenterLogic
class CaseCenter(BaseHandler):
 def initialize(self):
  super().initialize()
  pass
 def __del__(self):
  pass
 @property
 def logic(self):
  return CaseCenterLogic()
 def get_case_list(self):
  body=json.loads(self.request.body)
  conditions=body["conditions"]
  task_id=body["task_id"]
  return self.logic.get_case_list(conditions=conditions,task_id=task_id)
 def report_case_result(self):
  body=json.loads(self.request.body)
  task_id=body["task_id"]
  module_name=body["module_name"]
  case_name=body["case_name"]
  nick_name=body["nick_name"]
  open_id=body["open_id"]
  device_id=body["device_id"]
  result=body["result"]
  return self.logic.report_case_result(task_id=task_id,module_name=module_name,case_name=case_name,nick_name=nick_name,open_id=open_id,device_id=device_id,result=result,)
 def inject_cases(self):
  body=json.loads(self.request.body)
  cases=body["cases"]
  task_id=body["task_id"]
  return self.logic.inject_cases(cases=cases,task_id=task_id)
 def get_case_result(self):
  task_id=self.get_argument("task_id")
  return self.logic.get_case_result(task_id=task_id)
# Created by pyminifier (https://github.com/liftoff/pyminifier)
