#!/usr/local/bin/python3
# -*- coding: utf-8 -*-
from..library.base_logic import BaseLogic
from tornado.options import options
import logging.handlers
import json
import sqlite3
import base64
case_db_path=options.db_path
logger=logging.getLogger("CaseService")
logger.setLevel(logging.DEBUG)
class CaseCenterLogic(BaseLogic):
 def __init__(self):
  super(CaseCenterLogic,self).__init__()
 def __del__(self):
  pass
 def get_case_list(self,conditions,task_id):
  logger.info("get case")
  logger.debug(json.dumps(conditions))
  try:
   conn=sqlite3.connect(case_db_path)
   c=conn.cursor()
   sql="select * from task where task_id='%s'"%task_id
   c.execute(sql)
   cases_for_return=list()
   case_list=None
   for row in c:
    case_list_str=row[1]
    case_list=json.loads(case_list_str)
    for case in case_list:
     if case["flag"]!=0:
      continue
     cases_for_return.append(case)
     case["flag"]=1
     if len(cases_for_return)>5:
      break
   logger.info("get case success")
   logger.debug(f"{cases_for_return}")
   logger.info("update case database")
   sql_update="update task set cases='%s' where task_id='%s'"%(json.dumps(case_list),task_id,)
   c.execute(sql_update)
   conn.commit()
   c.close()
   return self.ok(cases=json.dumps(cases_for_return))
  except Exception as e:
   logger.error(f"get case fail, {str(e)}")
   return self.fail(reason=str(e))
 def report_case_result(self,task_id,module_name,case_name,nick_name,open_id,device_id,result):
  try:
   logger.info(f"receive {module_name}.{case_name} report")
   logger.debug(json.dumps(result))
   conn=sqlite3.connect(case_db_path)
   c=conn.cursor()
   sql=("insert into result values ('%s', '%s', '%s', '%s', '%s', '%s', '%s')"%(task_id,module_name,case_name,nick_name,open_id,device_id,base64.b64encode(json.dumps(result).encode(encoding="utf-8")).decode(),))
   logger.debug(sql)
   c.execute(sql)
   conn.commit()
   c.close()
   return self.ok()
  except Exception as e:
   logger.exception(e)
   return self.fail(reason=str(e))
 def get_case_result(self,task_id):
  try:
   logger.info(f"get all cases result of task: {task_id}")
   conn=sqlite3.connect(case_db_path)
   c=conn.cursor()
   sql="select * from result where task_id='%s'"%task_id
   c.execute(sql)
   result_list=list()
   for row in c:
    res=dict()
    res["task_id"]=row[0]
    res["module_name"]=row[1]
    res["case_name"]=row[2]
    res["nick_name"]=row[3]
    res["open_id"]=row[4]
    res["device_id"]=row[5]
    res["result"]=base64.b64decode(row[6]).decode(encoding="utf-8")
    result_list.append(res)
   return self.ok(results=json.dumps(result_list))
  except Exception as e:
   logger.exception(e)
   return self.fail(reason=str(e))
 def inject_cases(self,cases:list,task_id:str):
  try:
   for item in cases:
    item["flag"]=0
   conn=sqlite3.connect(case_db_path)
   c=conn.cursor()
   data=json.dumps(cases)
   sql="insert into task values ('%s', '%s')"%(task_id,data)
   c.execute(sql)
   conn.commit()
   c.close()
   logger.info(f"inject {len(cases)} cases")
   logger.debug(cases)
   return self.ok()
  except Exception as e:
   logger.exception(e)
   return self.fail(reason=str(e))
# Created by pyminifier (https://github.com/liftoff/pyminifier)
