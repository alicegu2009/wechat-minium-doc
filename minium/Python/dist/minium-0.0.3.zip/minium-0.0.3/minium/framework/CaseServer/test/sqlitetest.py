#!/usr/local/bin/python3
# -*- coding: utf-8 -*-
import sqlite3
import json
def inject():
 conn=sqlite3.connect("../storage/case.db")
 c=conn.cursor()
 data=json.dumps({"module_name":"nativetest","case_name":"test_forward"})
 task_id="jfklajsflkajslkfjalskflak"
 sql="insert into result values ('9868bb62-3d01-4fcd-9ca4-a814f0856e6e', 'componenttest', 'test_input_element', 'IkludGNJblJsYzNSZmJuVnRYQ0k2SURFc0lGd2laWEp5YjNKelhDSTZJRnRkTENCY0ltWmhhV3gxY21WelhDSTZJRnRkTENCY0ltTnNZWE56WDJWeWNtOXljMXdpT2lCYlhTd2dYQ0pqYkdGemMxOW1ZV2xzZFhKbGMxd2lPaUJiWFgwaSI=')"
 print(sql)
 c.execute(sql)
 conn.commit()
 c.close()
def query():
 conn=sqlite3.connect("../storage/case.db")
 c=conn.cursor()
 sql="select * from task"
 c.execute(sql)
 print(c.rowcount)
 for row in c:
  case_list_str=row[1]
  case_list=json.loads(case_list_str)
  case=case_list.pop()
  print(case)
 c.close()
if __name__=="__main__":
 inject()
# Created by pyminifier (https://github.com/liftoff/pyminifier)
