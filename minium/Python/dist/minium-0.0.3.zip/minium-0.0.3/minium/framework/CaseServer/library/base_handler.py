#!/usr/local/bin/python3
# -*- coding: utf-8 -*-
import json
import datetime
import logging
from tornado.web import RequestHandler
from tornado.options import options
logger=logging.getLogger()
def get_option(name,default=None):
 return options[name]if name in options else default
DEBUG=get_option("debug",False)
DEFAULT_USER=get_option("default_username","no_default_name")
class JsonEncoder(json.JSONEncoder):
 def default(self,obj):
  if isinstance(obj,datetime.datetime):
   return obj.strftime("%Y-%m-%d %H:%M:%S")
  else:
   return json.JSONEncoder.default(self,obj)
class BaseHandler(RequestHandler):
 cls_recent_login_users=[]
 def initialize(self):
  self.user_name=DEFAULT_USER
  self.action=None
  self.action_result={"msg":"","rtn":0}
 def data_received(self,chunk):
  pass
 def get_header(self,_name,_default):
  return self.request.headers.get(_name,_default)
 def check_action(self):
  if self.action.startswith("_"):
   self.action_result["msg"]="Illegal action %s"%self.action
   self.action_result["rtn"]=402
   return False
  if not hasattr(self,self.action):
   self.action_result["msg"]="Action func %s doesn't exist!"%self.action
   self.action_result["rtn"]=403
   return False
  return True
 def write_response(self):
  resp_buffer=json.dumps(self.action_result,cls=JsonEncoder)
  jsonp_callback=self.get_argument("jsonp_callback",None)
  if jsonp_callback:
   resp_buffer="%s( %s )"%(jsonp_callback,resp_buffer)
  self.write(resp_buffer)
 def get(self,action):
  self.action=action
  try:
   func_result=getattr(self,self.action)()
   if not isinstance(func_result,dict):
    return
  except Exception as e:
   logger.exception(e)
   raise
  self.action_result.update(func_result)
  self.write_response()
 post=get
# Created by pyminifier (https://github.com/liftoff/pyminifier)
