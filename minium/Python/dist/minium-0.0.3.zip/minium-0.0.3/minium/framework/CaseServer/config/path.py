#!/usr/local/bin/python3
# -*- coding: utf-8 -*-
import os
import sys
_file_dir=os.path.dirname(os.path.realpath(__file__))
SRC_ROOT=os.path.dirname(_file_dir)
def add_sys_paths():
 for _dir in("controllers","logics","libraries","models","config","workers"):
  _path=os.path.join(SRC_ROOT,_dir)
  sys.path.insert(0,_path)
# Created by pyminifier (https://github.com/liftoff/pyminifier)
