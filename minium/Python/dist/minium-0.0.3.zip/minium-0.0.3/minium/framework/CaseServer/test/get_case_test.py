#!/usr/local/bin/python3
# -*- coding: utf-8 -*-
import requests
import json
def get_case():
 retry=3
 while retry>0:
  data=json.dumps({"task_id":"fd34bb57-1b90-4486-ae20-a5d4c18419db","conditions":{"platform":"wx","os_type":"ios"},})
  rtn=requests.post(url=f"http://10.33.132.96:59573/case_center/get_case_list",data=data,headers={"Content-Type":"application/json"},)
  if rtn.status_code==200:
   cases=json.loads(json.loads(rtn.text).get("cases","[]"))
   return None
if __name__=="__main__":
 get_case()
# Created by pyminifier (https://github.com/liftoff/pyminifier)
