#!/usr/bin/env python3
import sys
import os.path
import argparse
import unittest
import logging.handlers
import json
import glob
import fnmatch
import requests
from.minisuite import MiniSuite
from.session import Session
from uuid import uuid4
from minium import build_version
from minium.framework import case_inspect
from minium.framework import minitest
from minium.framework import assertbase
from minium.framework import miniconfig
from minium.framework import miniresult
from minium.framework import report
from minium.miniprogram.wx_minium import WXMinium
logger=logging.getLogger()
FILENAME_SUMMARY="summary.json"
def run_tests(tests,mini_suite):
 result=miniresult.MiniResult(mini_suite)
 tests.run(result)
 result.print_shot_msg()
 return result
def load_from_suite(case_path,json_path,case_push_link,task_id):
 mini_suite=MiniSuite(json_path)
 tests=unittest.TestSuite()
 case_list_push=list()
 logger.debug("==========Scan Cases from suite===========")
 for pkg_cases in mini_suite.pkg_list:
  pkg=pkg_cases["pkg"]
  case_list=pkg_cases["case_list"]
  true_pkg_list=[]
  for case_suite_info in case_list:
   if isinstance(case_suite_info,str):
    case_name=case_suite_info
   else:
    case_name=case_suite_info["name"]
   module_case_info_list=case_inspect.load_module(case_path,pkg)
   for module_name,module_info in module_case_info_list.items():
    logger.debug(f"- {module_name}")
    for case_info in module_info["case_list"]:
     if fnmatch.fnmatch(case_info["name"],case_name):
      logger.debug(f"  |--{case_info['name']}")
      if case_push_link:
       case_list_push.append({"module_name":module_name,"case_name":case_info["name"],})
      _=load_from_case_name(module_name,case_info["name"])
      tests.addTests(_)
    true_pkg_list.append(module_name)
 if len(case_list_push)>0 and case_push_link:
  case=json.dumps({"task_id":str(task_id),"cases":case_list_push})
  rtn=requests.post(url=case_push_link,data=case,headers={"Content-Type":"application/json"})
  logger.info(f"upload cases: {rtn.status_code}:{rtn.reason}")
  logger.info(f"task id: {task_id}")
 return tests,mini_suite
def load_from_pkg(pkg):
 logger.debug(f"Loading Module: {pkg}")
 loader=unittest.TestLoader()
 test_module=case_inspect.import_module(pkg)
 tests=loader.loadTestsFromModule(test_module)
 return tests
def load_from_case_name(pkg,case_name):
 logger.debug(f"Loading Case: {pkg}.{case_name}")
 loader=unittest.TestLoader()
 test_class=case_inspect.find_test_class(pkg,case_name)
 if test_class:
  return loader.loadTestsFromName(case_name,test_class)
 else:
  raise AssertionError("can't not find testcase %s in pkg %s"%(case_name,pkg))
def main():
 parsers=argparse.ArgumentParser()
 parsers.add_argument("-v","--version",dest="version",action="store_true",default=False)
 parsers.add_argument("-t","--path",dest="path",type=str,help="case directory, default current directory",default=None,)
 parsers.add_argument("-p","--pkg",dest="pkg",type=str,help="case package name")
 parsers.add_argument("-c","--case",dest="case_name",type=str,default=None,help="case name")
 parsers.add_argument("--source",dest="sys_path_list",nargs="*",help="module search path")
 parsers.add_argument("-k","--apk",dest="apk",action="store_true",default=False,help="show apk path",)
 parsers.add_argument("-s","--suite",dest="suite_path",type=str,default=None,help="test suite file, a json format file",)
 parsers.add_argument("-f","--config",dest="config",type=str,default=None,help="config file path")
 parsers.add_argument("-g","--generate",dest="generate",action="store_true",default=False,help="generate html report",)
 parsers.add_argument("-l","--link",dest="case_service_link",type=str,default=None,help="Enable use Case Service",)
 parsers.add_argument("-i","--task-id",dest="task_id",type=str,default=None,help="when you send cases to case server, you will get a task id",)
 parsers.add_argument("-a","--accounts",dest="accounts",action="store_true")
 parsers.format_help()
 parser_args=parsers.parse_args()
 version=parser_args.version
 path=parser_args.path
 pkg=parser_args.pkg
 apk=parser_args.apk
 case_name=parser_args.case_name
 generate_report=parser_args.generate
 suite_path=parser_args.suite_path
 config=parser_args.config
 sys_path_list=parser_args.sys_path_list
 case_service_link=parser_args.case_service_link
 task_id=parser_args.task_id
 show_accounts=parser_args.accounts
 if show_accounts:
  print(WXMinium().get_test_accounts())
  exit(0)
 if sys_path_list:
  for sys_path in sys_path_list:
   logger.info("insert %s to sys.path",sys_path)
   sys.path.insert(0,sys_path)
 if version:
  print(build_version())
  exit(0)
 if apk:
  bin_root=os.path.join(os.path.dirname(os.path.dirname(__file__)),"native","lib","at","bin","*apk",)
  print("please install apk:")
  for filename in glob.glob(bin_root):
   print(f"adb install -r {filename}")
  exit(0)
 if path is None:
  logger.debug("path not specified, use current path")
  path=os.getcwd()
 if not os.path.exists(path)or not os.path.isdir(path):
  logger.error("case directory: %s not exists"%path)
  parsers.print_help()
  exit(0)
 sys.path.insert(0,path)
 minitest.AssertBase.setUpConfig()
 mini_suite=MiniSuite()
 tests=None
 if suite_path:
  case_push_link=None
  if not task_id:
   task_id=uuid4()
  if case_service_link:
   if "http://" not in case_service_link:
    case_service_link="http://"+case_service_link
   case_push_link=f"{case_service_link}/case_center/inject_cases"
  tests,mini_suite=load_from_suite(path,suite_path,case_push_link,task_id)
 elif pkg is None:
  logger.error("need suite_path or pkg")
  parsers.print_help()
  exit(0)
 elif case_name is None:
  tests=load_from_pkg(pkg)
 else:
  tests=load_from_case_name(pkg,case_name)
 if config and not os.path.exists(config):
  logger.error("config not exists:%s"%config)
  parsers.print_help()
  exit(0)
 if config:
  conf=miniconfig.MiniConfig.from_file(config)
  if isinstance(conf,list):
   session_list=list()
   for c in conf:
    s=Session(conf=c,task_id=task_id,case_server_address=case_service_link,generate_report=generate_report,)
    s.start()
    session_list.append(s)
   for se in session_list:
    se.join()
   exit(0)
  else:
   minitest.AssertBase.CONFIG=miniconfig.MiniConfig.from_file(config)
 minitest.AssertBase.setUpConfig()
 assertbase.g_from_command=True
 if not case_service_link:
  try:
   logger.debug(f"=====================Run case in local=====================")
   result=run_tests(tests,mini_suite)
   summary_path=os.path.join(minitest.AssertBase.CONFIG.outputs,FILENAME_SUMMARY)
   result.dumps(summary_path)
   if generate_report:
    report.imp_main(minitest.AssertBase.CONFIG.outputs)
  except Exception as e:
   logger.exception(e)
if __name__=="__main__":
 main()
# Created by pyminifier (https://github.com/liftoff/pyminifier)
