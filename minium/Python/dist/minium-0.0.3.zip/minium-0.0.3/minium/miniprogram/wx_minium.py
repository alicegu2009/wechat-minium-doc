#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import time
import platform
import os
import base64
import json
from.base_driver.error import*
from.base_driver.app import App
from.base_driver.connection import Connection
from.base_driver.minium_object import MiniumObject
from..framework.miniconfig import default_config
LOG_FORMATTER="%(levelname)-5.5s %(asctime)s %(filename)-10s %(funcName)-15s %(lineno)-3d %(message)s"
MAC_DEVTOOL_PATH="/Applications/wechatwebdevtools.app/Contents/MacOS/cli"
WINDOWS_DEVTOOL_PATH="cli"
TEST_PORT=9420
UPLOAD_URL="https://stream.weixin.qq.com/weapp/UploadFile"
cur_path=os.path.dirname(os.path.realpath(__file__))
resource_path=os.path.join(os.path.dirname(cur_path),"wx_resources")
if not os.path.exists(resource_path):
 os.mkdir(resource_path)
class LogLevel(object):
 INFO=20
 DEBUG_SEND=12
 METHOD_TRACE=11
 DEBUG=9
def build_version():
 config_path=os.path.join(os.path.dirname(__file__),"version.json")
 if not os.path.exists(config_path):
  return{}
 else:
  with open(config_path,"rb")as f:
   version=json.load(f)
   return version
class WXMinium(MiniumObject):
 def __init__(self,conf=None,uri="ws://localhost"):
  super().__init__()
  if not conf:
   conf=default_config
  self.version=build_version()
  self.logger.info(self.version)
  self.sessions={}
  self.app=None
  self.connection=None
  test_port=(str(conf.test_port)if conf.get("test_port",None)else str(TEST_PORT))
  self.uri=uri+":"+test_port
  self.test_port=test_port
  self.open_id=conf.get("account_info",{}).get("open_id",None)
  self.project_path=conf.get("project_path",None)
  self.is_remote=False
  if conf.get("dev_tool_path",None):
   self.dev_tool_path=conf.dev_tool_path
  elif "Darwin" in platform.platform():
   self.dev_tool_path=MAC_DEVTOOL_PATH
  elif "Windows" in platform.platform():
   self.dev_tool_path=WINDOWS_DEVTOOL_PATH
  else:
   self.logger.warning("Dev tool doesn't support current OS yet")
  self._is_windows="Windows" in platform.platform()
  self.launch_dev_tool()
  if conf.get("platform",None)!="ide":
   path=self.enable_remote_debug(use_push=conf.get("use_push",True),connect_timeout=conf.get("remote_connect_timeout",180),)
   self.qr_code=path
 def _dev_cli(self,cmd):
  if not self.dev_tool_path or not os.path.exists(self.dev_tool_path):
   raise MiniumEnvError("dev_tool_path: %s not exists"%self.dev_tool_path)
  if self._is_windows:
   cmd_template='"%s"  %s'
  else:
   cmd_template="%s %s"
  return self._do_shell(cmd_template%(self.dev_tool_path,cmd))
 def launch_dev_tool(self):
  self.logger.info("Starting dev tool ...")
  if self.project_path:
   if not os.path.exists(self.project_path):
    raise MiniumEnvError("project_path: %s not exists"%self.project_path)
   if not os.path.isdir(self.project_path):
    raise MiniumEnvError("project_path: %s is not directory"%self.project_path)
   start_cmd="--auto %s --auto-port %s"%(self.project_path,self.test_port)
   if self.open_id:
    start_cmd+=f" --auto-account {self.open_id}"
   status=self._dev_cli(start_cmd)
   if self._is_windows:
    time.sleep(10)
   else:
    time.sleep(5)
   if status[-1]=="" or "Port %s is in use"%self.test_port in status[-1]:
    self.logger.info("Dev tool is opening, but can't open project, quit now...")
    if self.connect_dev_tool():
     return
    self._dev_cli("--quit")
    time.sleep(3)
    self.logger.info("Starting dev tool again...")
    status=self._dev_cli(start_cmd)
    if status[-1]=="":
     raise Exception("Please check MiniProgram project if config error or not")
    else:
     self.logger.info("Restart finish")
     time.sleep(5)
  else:
   status=["Open project with automation enabled success  /Users/sherlock/svn/demo"]
  if "Open project with automation enabled success " in status[-1]:
   self.connect_dev_tool()
  else:
   self.logger.warning( """Open project in automation mode fail! Please try to open project :
                %s -o %s"""   
   %(self.dev_tool_path,self.project_path))
 def connect_dev_tool(self):
  i=3
  relaunch=False
  while i:
   try:
    self.logger.info("Trying to connect Dev tool ...")
    connection=Connection(self.uri)
    self.app=App(connection,relaunch)
    self.connection=connection
   except Exception as e:
    i-=1
    if i==0:
     self.logger.error("three times try to connect Dev tool all fail ...")
     self.logger.warning("Please check the remote debug window in Dev tool is closed or not, if not, just close it and try again")
     raise
    self.logger.warning(e)
    relaunch=True
    continue
   else:
    break
  return True
 def launch_dev_tool_with_login(self):
  cmd_start="-l --login-qr-output terminal --auto --auto %s --auto-port %s"%(self.project_path,self.test_port,)
  status=self._dev_cli(cmd_start)
  if "Open project with automation enabled success " in status[-1]:
   connection=Connection(self.uri)
   self.app=App(connection)
   self.connection=connection
  else:
   self.logger.error("Open project in automation mode fail! make sure project path is right")
   exit(-1)
 def get_app_config(self):
  return(self.evaluate("function () {return __wxConfig}",sync=True).get("result",{"result":{}}).get("result",None))
 def get_system_info(self):
  return(self.app.call_wx_method("getSystemInfoSync").get("result",{"result":{}}).get("result",None))
 def enable_remote_debug(self,use_push=True,path=None,connect_timeout=None):
  if connect_timeout is None:
   connect_timeout=180
  if use_push:
   retry_times=3
   while retry_times>0:
    try:
     self.logger.info(f"Enable remote debug, for the {4 - retry_times}th times")
     self.connection.send("Tool.enableRemoteDebug",params={"auto":True},max_timeout=connect_timeout,)
     self.is_remote=True
    except Exception as e:
     retry_times-=1
     self.logger.error("enable remote debug fail ...")
     self.logger.error(e)
     if retry_times==0:
      self.logger.error("Enable remote debug has been fail three times. Please check your network or proxy effective or not")
      raise
     continue
    else:
     retry_times-=1
     rtn=self.connection.wait_for(method="App.initialized",max_timeout=connect_timeout)
     if retry_times==0 and rtn is False:
      self.logger.error("Wait for APP initialized has been fail three times. Please check your phone's current foreground APP is WeChat or not, and check miniProgram has been open or not")
      raise
     if rtn is True:
      break
     else:
      self.app.exit()
   return None
  if path is None:
   path=os.path.join(resource_path,"debug_qrcode.jpg")
  qr_data=self.connection.send("Tool.enableRemoteDebug",max_timeout=connect_timeout).result.qrCode
  with open(path,"wb")as qr_img:
   qr_img.write(base64.b64decode(qr_data))
  return path
 def clear_auth(self):
  self.connection.send("Tool.clearAuth")
 def get_test_accounts(self):
  return self.connection.send("Tool.getTestAccounts").result.accounts
 def shutdown(self):
  try:
   if self.is_remote:
    self.logger.info("MiniProgram closing")
    self.app.exit()
   self.logger.info("Dev tool closing")
   self.connection.send("Tool.close")
   time.sleep(5)
  except Exception as e:
   self.logger.exception(e)
if __name__=="__main__":
 mini=WXMinium()
# Created by pyminifier (https://github.com/liftoff/pyminifier)
