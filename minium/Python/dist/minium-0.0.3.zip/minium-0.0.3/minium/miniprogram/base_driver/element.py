#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from.minium_object import MiniumObject,timeout
import time
from.prefixer import*
class BaseElement(MiniumObject):
 def __init__(self,element,page_id,connection):
  super().__init__()
  self.element_id=element.elementId
  self.page_id=page_id
  self._tag_name=element.tagName
  self.connection=connection
 @property
 def data(self):
  return
 @data.setter
 def data(self,data):
  pass
 def call_method(self,method:str,*params):
  pass
 def call_func(self,func:str,args=None):
  return self._send("Element.callFunction",{"functionName":func,"args":args})
 def tap(self):
  self._send("Element.tap")
 def click(self):
  styles=self.styles("pointer-events")
  if styles and styles[0]=="none":
   self.logger.warning("can't click, because pointer-events is none")
   return
  self._send("Element.tap")
  time.sleep(1)
 def move(self,x_offset,y_offset,move_delay=350,smooth=False):
  self._move(x_offset=x_offset,y_offset=y_offset,move_delay=move_delay,smooth=smooth)
 def long_press(self,duration=350):
  offset=self.offset
  size=self.size
  ori_changed_touch=ori_touch={"identifier":0,"pageX":offset["left"]+size["width"]//2,"pageY":offset["top"]+size["height"]//2,"clientX":offset["left"]+size["width"]//2-self.page_scroll_x,"clientY":offset["top"]+size["height"]//2-self.page_scroll_y,}
  self._touch_start(touches=[ori_touch],changed_touches=[ori_changed_touch])
  time.sleep(duration/1000)
  self._touch_end(changed_touches=[ori_changed_touch])
 def touch_start(self,touches:list,changed_touches:list):
  self._touch_start(touches=touches,changed_touches=changed_touches)
 def touch_end(self,changed_touches:list):
  self._touch_end(changed_touches=changed_touches)
 def touch_move(self,touches:list,changed_touches:list):
  self._touch_move(touches=touches,changed_touches=changed_touches)
 def touch_cancel(self):
  self._send("Element.touchcancel")
 def slide(self,direction,distance):
  raise NotImplementedError()
 def get_element(self,selector,inner_text=None,value=None,text_contains=None,max_timeout=10):
  @timeout(max_timeout)
  def _f():
   elements=self._get_elements(selector,max_timeout)
   if not elements:
    return True
   for element in elements:
    if inner_text and element.inner_text!=inner_text:
     continue
    if value and element.value()!=value:
     continue
    if text_contains and text_contains not in element.inner_text:
     continue
    return element
   return False
  try:
   r=_f()
   if r is True:
    return None
   else:
    return r
  except:
   return None
 def get_elements(self,selector,max_timeout=10):
  return self._get_elements(selector,max_timeout)
 def attribute(self,name):
  return self._getter("getAttributes","attributes",name)
 @property
 def size(self):
  size_arr=self._dom_property(["offsetWidth","offsetHeight"])
  return{"width":size_arr[0],"height":size_arr[1]}
 @property
 def offset(self):
  rtn=self._send("Element.getOffset")
  return rtn.get("result")
 @property
 def rect(self):
  rect_arr=self._dom_property(["offsetWidth","offsetHeight"])
  offset=self.offset
  return{"left":offset["left"],"top":offset["top"],"width":rect_arr[0],"height":rect_arr[1],}
 def styles(self,names):
  return self._getter("getStyles","styles",names)
 @property
 def page_scroll_x(self):
  return self._get_window_properties(["scrollX"])[0]
 @property
 def page_scroll_y(self):
  return self._get_window_properties(["scrollY"])[0]
 @property
 def value(self):
  return self._property("value")[0]
 @property
 def inner_text(self):
  return self._dom_property("innerText")[0]
 @property
 def inner_wxml(self):
  return self._send("Element.getWXML",{"type":"inner"}).result.wxml
 @property
 def outer_wxml(self):
  return self._send("Element.getWXML",{"type":"outer"}).result.wxml
 def _property(self,name):
  return self._getter("getProperties","properties",name)
 def _dom_property(self,name):
  return self._getter("getDOMProperties","properties",name)
 def trigger(self,trigger_type,detail):
  return self._trigger(trigger_type,detail)
 def _get_window_properties(self,names=None):
  if names is None:
   names=[]
  return self._send("Page.getWindowProperties",{"names":names}).result.properties
 def _trigger(self,trigger_type,detail):
  params=dict()
  params["type"]=trigger_type
  if detail:
   params["detail"]=detail
  return self._send("Element.triggerEvent",params)
 def _getter(self,method,return_name,names=""):
  if isinstance(names,list):
   result=self._send("Element."+method,{"names":names})
  elif isinstance(names,str):
   result=self._send("Element."+method,{"names":[names]})
  else:
   raise Exception("invalid names type")
  ret=getattr(result.result,return_name)
  return ret
 def _send(self,method,params=None):
  if params is None:
   params={}
  params["elementId"]=self.element_id
  params["pageId"]=self.page_id
  return self.connection.send(method,params)
 def _move(self,x_offset,y_offset,move_delay=350,smooth=False):
  offset=self.offset
  size=self.size
  changed_touch=touch=ori_changed_touch=ori_touch={"identifier":0,"pageX":offset["left"]+size["width"]//2,"pageY":offset["top"]+size["height"]//2,"clientX":offset["left"]+size["width"]//2-self.page_scroll_x,"clientY":offset["top"]+size["height"]//2-self.page_scroll_y,}
  self._touch_start(touches=[ori_touch],changed_touches=[ori_changed_touch])
  time.sleep(move_delay/1000)
  if smooth:
   temp_x_offset=temp_y_offset=0
   while abs(temp_x_offset)<abs(x_offset)or abs(temp_y_offset)<abs(y_offset):
    if not x_offset==0:
     temp_x_offset=((temp_x_offset+1)if x_offset>0 else(temp_x_offset-1))
    if not y_offset==0:
     temp_y_offset=((temp_y_offset+1)if y_offset>0 else(temp_y_offset-1))
    changed_touch=touch={"identifier":0,"pageX":offset["left"]+size["width"]//2+temp_x_offset,"pageY":offset["top"]+size["height"]//2+temp_y_offset,"clientX":offset["left"]+size["width"]//2-self.page_scroll_x+temp_x_offset,"clientY":offset["top"]+size["height"]//2-self.page_scroll_y+temp_y_offset,}
    self._touch_move(touches=[touch],changed_touches=[changed_touch])
  else:
   changed_touch=touch={"identifier":0,"pageX":offset["left"]+size["width"]//2+x_offset,"pageY":offset["top"]+size["height"]//2+y_offset,"clientX":offset["left"]+size["width"]//2-self.page_scroll_x+x_offset,"clientY":offset["top"]+size["height"]//2-self.page_scroll_y+y_offset,}
   self._touch_move(touches=[touch],changed_touches=[changed_touch])
  time.sleep(move_delay/1000)
  self._touch_end(changed_touches=[changed_touch])
 def _touch_start(self,touches:list,changed_touches:list):
  self._send("Element.touchstart",params={"touches":touches,"changedTouches":changed_touches},)
 def _touch_move(self,touches:list,changed_touches:list):
  self._send("Element.touchmove",params={"touches":touches,"changedTouches":changed_touches},)
 def _touch_end(self,changed_touches:list):
  touches=[]
  self._send("Element.touchend",params={"touches":touches,"changedTouches":changed_touches},)
 def _get_elements(self,selector,max_timeout=10):
  elements=[]
  @timeout(max_timeout)
  def refresh_elements():
   ret=self._send("Element.getElements",{"selector":selector})
   if hasattr(ret,"error"):
    raise Exception("Element not found with selector: [%s], cause: %s"%(selector,ret.error))
   for el in ret.result.elements:
    if "nodeId" in el.keys():
     element_cus=CustomElement(el,self.page_id,self.connection)
     elements.append(element_cus)
    else:
     element=eval(ELEMENT_TYPE.get(el.tagName,"BaseElement"))(el,self.page_id,self.connection)
     elements.append(element)
   return elements
  try:
   self.logger.info("try to find elements: %s"%selector)
   refresh_elements()
   self.logger.info("find elements success: %s"%str(elements))
   return elements
  except Exception as e:
   self.logger.exception("elements search fail cause: "+str(e))
   return[]
class FormElement(BaseElement):
 def __init__(self,element,page_id,connection):
  super(FormElement,self).__init__(element,page_id,connection)
 def input(self,text):
  if self._tag_name!="input" and self._tag_name!="textarea":
   self.logger.warning("Element's type is not fit for the method which you call")
   return
  func="{x}.input".format(x=self._tag_name)
  self.call_func(func,args=[text])
 def pick(self,value):
  if self._tag_name!="picker":
   self.logger.warning("Element's type is not fit for the method which you call")
   return
  return
 def switch(self):
  if self._tag_name!="switch":
   self.logger.warning("Element's type is not fit for the method which you call")
   return
  func="switch.tap"
  self.call_func(func,args=[])
 def slide_to(self,value):
  if self._tag_name!="slider":
   self.logger.warning("Element's type is not fit for the method which you call")
   return
  func="slider.slideTo"
  self.call_func(func,args=[value])
class ViewElement(BaseElement):
 def __init__(self,element,page_id,connection):
  super(ViewElement,self).__init__(element,page_id,connection)
 def scroll_to(self,x=0,y=0):
  if self._tag_name!="scroll-view":
   self.logger.warning("Element's type is not fit for the method which you call")
   return
  func="scroll-view.scrollTo"
  self.call_func(func,args=[x,y])
 def swipe_to(self,index):
  if self._tag_name!="swiper":
   self.logger.warning("Element's type is not fit for the method which you call")
   return
  func="swiper.swipeTo"
  self.call_func(func,args=[index])
 def move_to(self,x,y):
  if self._tag_name!="movable-view":
   self.logger.warning("Element's type is not fit for the method which you call")
   return
  func="movable-view.moveTo"
  self.call_func(func,args=[x,y])
class VideoElement(BaseElement):
 def __init__(self,element,page_id,connection):
  super(VideoElement,self).__init__(element,page_id,connection)
  self.video_id=element.get("videoId",None)
  self.controller=VideoController(connection,self.video_id)
  self.media_type=MediaType.VIDEO
 def _call_context_method(self,method:str,args:list):
  params={"videoId":self.video_id,"method":method,"args":args}
  return self._send("Element.callContextMethod",params=params)
 def play(self):
  self.controller.play()
 def pause(self):
  self.controller.pause()
 def stop(self):
  self.controller.stop()
 def seek(self,position:int):
  self.controller.seek(position)
 def send_danmu(self,text:str,color="#000000"):
  self.controller.send_danmu(text,color)
 def playback_rate(self,rate:float):
  self.controller.playback_rate(rate)
 def request_full_screen(self,direction=0):
  self.controller.request_full_screen(direction)
 def exit_full_screen(self):
  self.controller.exit_full_screen()
 def show_status_bar(self):
  self.controller.show_status_bar()
 def hide_status_bar(self):
  self.controller.hide_status_bar()
class AudioElement(BaseElement):
 def __init__(self,element,page_id,connection):
  super(AudioElement,self).__init__(element,page_id,connection)
  self.controller=AudioController(connection)
  self.media_type=MediaType.AUDIO
 def set_src(self,src):
  self.controller.set_src(src)
 def play(self):
  self.controller.play()
 def pause(self):
  self.controller.pause()
 def seek(self,position):
  self.controller.seek(position)
class LivePlayerElement(BaseElement):
 def __init__(self,element,page_id,connection):
  super(LivePlayerElement,self).__init__(element,page_id,connection)
  self.controller=LivePlayerController(connection)
  self.media_type=MediaType.LIVE_PLAY
 def play(self):
  self.controller.play()
 def stop(self):
  self.controller.stop()
 def mute(self):
  self.controller.mute()
 def pause(self):
  self.controller.pause()
 def resume(self):
  self.controller.resume()
 def request_full_screen(self,direction=0):
  self.controller.request_full_screen(direction)
 def exit_full_screen(self):
  self.controller.exit_full_screen()
 def snapshot(self):
  self.controller.snapshot()
class LivePusherElement(BaseElement):
 def __init__(self,element,page_id,connection):
  super(LivePusherElement,self).__init__(element,page_id,connection)
  self.controller=LivePusherController(connection)
  self.media_type=MediaType.LIVE_PUSH
 def start(self):
  self.controller.start()
 def stop(self):
  self.controller.stop()
 def pause(self):
  self.controller.pause()
 def resume(self):
  self.controller.resume()
 def switch_camera(self):
  self.controller.switch_camera()
 def snapshot(self):
  self.controller.snapshot()
 def toggle_torch(self):
  self.controller.toggle_torch()
 def play_bgm(self,url):
  self.controller.play_bgm(url)
 def stop_bgm(self):
  self.controller.stop_bgm()
 def pause_bgm(self):
  self.controller.pause_bgm()
 def resume_bgm(self):
  self.controller.resume_bgm()
 def set_bgm_volume(self,volume):
  self.controller.set_bgm_volume(volume)
 def start_preview(self):
  self.controller.start_preview()
 def stop_preview(self):
  self.controller.stop_preview()
class CustomElement(BaseElement):
 def __init__(self,element,page_id,connection):
  super(CustomElement,self).__init__(element,page_id,connection)
  self.node_id=element.get("nodeId",None)
 def _send(self,method,params=None):
  if params is None:
   params={}
  params["elementId"]=self.element_id
  params["pageId"]=self.page_id
  params["nodeId"]=self.node_id
  return self.connection.send(method,params)
 @property
 def data(self):
  return self._send("Element.getData").result.data
 @data.setter
 def data(self,data):
  self._send("Element.setData",{"data":data})
 def call_method(self,method:str,*params):
  if not params:
   params=[]
  return self._send("Element.callMethod",{"method":method,"args":params})
class MediaController(MiniumObject):
 def __init__(self):
  pass
class VideoController(MediaController):
 def __init__(self,connection,video_id):
  super().__init__()
  self.connection=connection
  self.video_id=video_id
 def play(self):
  self.evaluate("function(){global.minium.videoContext.play()}")
 def pause(self):
  self.evaluate("function(){global.minium.videoContext.pause()}")
 def stop(self):
  self.evaluate("function(){global.minium.videoContext.stop()}")
 def seek(self,position:int):
  self.evaluate("function(){global.minium.videoContext.seek(%s)}"%position)
 def send_danmu(self,text:str,color="#000000"):
  self.evaluate("function(){global.minium.videoContext.sendDanmu({text:'%s', color:'%s'})}"%(text,color))
 def playback_rate(self,rate):
  self.evaluate("function(){global.minium.videoContext.playbackRate(%s)}"%rate)
 def request_full_screen(self,direction=0):
  self.evaluate("function(){global.minium.videoContext.requestFullScreen({direction: %s})}"%direction)
 def exit_full_screen(self):
  self.evaluate("function(){global.minium.videoContext.exitFullScreen()}")
 def show_status_bar(self):
  self.evaluate("function(){global.minium.videoContext.showStatusBar()}")
 def hide_status_bar(self):
  self.evaluate("function(){global.minium.videoContext.hideStatusBar()}")
class AudioController(MediaController):
 def __init__(self,connection):
  super().__init__()
  self.connection=connection
 def set_src(self,src):
  self.evaluate("function(){global.minium.audioContext.setSrc(%s)}"%src)
 def play(self):
  self.evaluate("function(){global.minium.audioContext.play()}")
 def pause(self):
  self.evaluate("function(){global.minium.audioContext.pause()}")
 def seek(self,position):
  self.evaluate("function(){global.minium.audioContext.seek(%s)}"%position)
class LivePlayerController(MediaController):
 def __init__(self,connection):
  super().__init__()
  self.connection=connection
 def play(self):
  self.evaluate("function(){global.minium.livePlayerContext.play()}")
 def stop(self):
  self.evaluate("function(){global.minium.livePlayerContext.stop()}")
 def mute(self):
  self.evaluate("function(){global.minium.livePlayerContext.mute()}")
 def pause(self):
  self.evaluate("function(){global.minium.livePlayerContext.pause()}")
 def resume(self):
  self.evaluate("function(){global.minium.livePlayerContext.resume()}")
 def request_full_screen(self,direction=0):
  self.evaluate("function(){global.minium.livePlayerContext.requestFullScreen({direction: %s})}"%direction)
 def exit_full_screen(self):
  self.evaluate("function(){global.minium.livePlayerContext.exitFullScreen()}")
 def snapshot(self):
  self.evaluate("function(){global.minium.livePlayerContext.snapshot()}")
class LivePusherController(MediaController):
 def __init__(self,connection):
  super().__init__()
  self.connection=connection
 def start(self):
  self.evaluate("function(){global.minium.livePusherContext.start()}")
 def stop(self):
  self.evaluate("function(){global.minium.livePusherContext.stop()}")
 def pause(self):
  self.evaluate("function(){global.minium.livePusherContext.pause()}")
 def resume(self):
  self.evaluate("function(){global.minium.livePusherContext.resume()}")
 def switch_camera(self):
  self.evaluate("function(){global.minium.livePusherContext.switchCamera()}")
 def snapshot(self):
  self.evaluate("function(){global.minium.livePusherContext.snapshot()}")
 def toggle_torch(self):
  self.evaluate("function(){global.minium.livePusherContext.toggleTorch()}")
 def play_bgm(self,url):
  self.evaluate("function(){global.minium.livePusherContext.PlayBGM({url:'%s'})}"%url)
 def stop_bgm(self):
  self.evaluate("function(){global.minium.livePusherContext.stopBGM()}")
 def pause_bgm(self):
  self.evaluate("function(){global.minium.livePusherContext.pauseBGM()}")
 def resume_bgm(self):
  self.evaluate("function(){global.minium.livePusherContext.resumeBGM()}")
 def set_bgm_volume(self,volume):
  self.evaluate("function(){global.minium.livePusherContext.setBGMVolume({volume:'%s'})}"%volume)
 def start_preview(self):
  self.evaluate("function(){global.minium.livePusherContext.startPreview()}")
 def stop_preview(self):
  self.evaluate("function(){global.minium.livePusherContext.startPreview()}")
# Created by pyminifier (https://github.com/liftoff/pyminifier)
